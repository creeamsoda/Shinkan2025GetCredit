export class ResultRecorder{
    Score;
    GetCredits;
    FailCredits;

    constructor(){
        this.Score = 0;
        this.GetCredits = [];
        this.FailCredits = [];
    }
}